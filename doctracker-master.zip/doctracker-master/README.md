## Prerekvizity

- PHP 7.2+
- PHP mbstring
- PHP exec
- PHP mysql
- Composer (pre PHP)
- MySQL, SQLite alebo hocičo iné pre čo existuje "Doctrine driver". Aplikácia zatiaľ nevyužíva žiadne SQL query, ktoré by boli špecifické pre kontrétny typ RDBS.
- Pokiaľ sa ide použivať databaza mysql na Ubuntu tak ju treba nainstalovať podľa návodu na nasledujúcej stránke: https://www.digitalocean.com/community/tutorials/how-to-install-mysql-on-ubuntu-18-04 

Install MySQL, PHP and required modules:
```
$ sudo apt install mysql-server php php-mysql php-mbstring php-zip
```

Update MySQL password:
```
$ sudo mysql
> UPDATE mysql.user SET plugin = 'mysql_native_password' WHERE User = '...';
> UPDATE mysql.user SET authentication_string = PASSWORD('...') WHERE User = '...';
```

## Inštalácia

Predpokladajme, že sú súbory projektu uložené v adresári doctracker (napríklad checkout z gitu). PHP a Composer sú v ceste (path).

### Inštalácia závislostí

V hlavnom adresári projektu spustiť príkaz:

```
composer install
```

### Inicializácia databázy

V hlavnom adresári projektu vytvoriť súbor s názvom `.env`. 

Obsah súboru:

```
APP_ENV=dev
APP_SECRET=007071b808e4fd8beff0108a2588d844
DATABASE_URL=mysql://db_user:db_password@127.0.0.1:3306/db_name
```

Pre SQLite by mohol vyzerať konf string napr. takto: `DATABASE_URL="sqlite:///%kernel.project_dir%/var/app.db"`

Pri zadávaní príkazov treba byť v koreňovom adresári aplikácie.

Pre vytvorenie databázy v MySql je potrebné zadať nasledujúci príkaz:

```
php bin/console doctrine:database:create
```

Pre vytvorenie databázovej štruktúry zadať príkaz:

```
php bin/console doctrine:schema:update --force
```

Pre načitanie testovacích dát zadať príkaz

```
php bin/console doctrine:fixtures:load
```

### Spustenie aplikácie

Spustiť testovací webový server príkazom:

```
php bin/console server:run
```

Server štandartne počúva na adrese http://127.0.0.1:8000.

## Poznámky

### Testovacie kontá

V aplikácii je predvytorených niekoľko používateľských účtov:

#### admin

```
admin / Pokus123
```

Hlavný administrátor aplikácie.

Rola `ROLE_ADMIN`

Dedí roly `ROLE_USER` a `ROLE_CONTROLLING`.

Môže vykonávať všetky operácie. Nie je pridadený na žiadne oddelenie, preto mu nie je možné priradiť dokument na schválenie. Vidí všetky záznamy v histórii dokumentu.

Administrátor sa cez menu aplikácia môže prepnúť do konta ľubovoľného používateľa. Zatial to využívame len na testovanie aby sme sa nemuseli odhlasovať a prihlasovať alebo mať otvorených viacero browserov.
Vo finálnej verzii to môže byť deaktivované.

#### kontrola

```
kontrola / Pokus123
```

Používateľ oddelenia kontroly. 

Rola `ROLE_CONTROLLING`

Dedí rolu `ROLE_USER`

Môže vytvárať a upravovať dokumenty a vytvárať postupy ich schvaľovania. V histórii dokumentu vidí len záznamy, za ktoré nie je zodpovedný admin.

#### pravnik, riaditel, obstaravanie

```
pravnik / Pokus123
riaditel / Pokus123
obstaravanie / Pokus123
```

Rola `ROLE_USER`

Používateľské kontá, ktoré môžu schvaľovať dokumenty, ktoré boli pridelené ich oddeleniu. Na oddelení môže byť viac používateľov, ktorý môžu dokumenty schvaľovať.


---

Každý používateľ vidí po prihlásení obrazovku, ktoré zodpovedá jeho roly. ROLE_ADMIN a ROLE_CONTROLLING vidia zoznam dokumentov, ROLE_USER vidia dokumenty, ktoré čakajú na ich vyjadrenie.

## Emailové konto pre testovanie notifikacii
---
Pre testovacie účely bolo vytvorenie emailove konto v gmaily.

***Email má login v tvare: `test.emails.projects`*** 

***A prihlasovacie heslo: `Pokus123`***

Pre fungovanie emailových notifikácii je potrebné si nastaviť v súbore `.env` MAILER_URL nasledovne:

***MAILER_URL=gmail://test.emails.projects@gmail.com:Pokus123@localhost***  

