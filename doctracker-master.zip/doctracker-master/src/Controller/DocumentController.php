<?php

namespace App\Controller;

use App\Entity\Document\Attachment;
use App\Entity\Document\Document;
use App\Entity\Document\HistoryRecord;
use App\Entity\Document\ProcessingStep;
use App\Entity\Document\State;
use App\Entity\User\OrgUnit;
use App\Entity\User\User;
use App\Form\Document\ConfirmDocumentType;
use App\Form\Document\EditDocumentType;
use App\Form\Model\ConfirmationComment;
use App\Service\DocumentAttachmentService;
use App\Service\DocumentService;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use const Grpc\STATUS_ABORTED;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Validator\Constraints\Date;
use Twig\Node\Expression\Test\SameasTest;

/**
 * Class DocumentController
 * @Route("/documents")
 * @package App\Controller
 */
class DocumentController extends AbstractController
{
    /**
     * @Route("/", name="document_index")
     * @IsGranted("ROLE_CONTROLLING")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function indexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $document = $em->getRepository(Document::class)->findAll();
        return $this->render('document/index.html.twig', array(
            'documents' => $document
        ));
    }

    /**
     * @Route("/delete/{documentId}", name="document_delete")
     * @IsGranted("ROLE_CONTROLLING")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response     *
     */
    public function deleteDocumentAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $documentId = $request->get('documentId');
        $document = $em->find(Document::class, $documentId);
        try {
            $em->remove($document);
            $em->flush();
            $this->addFlash('success', "Dokument \"{$document->getName()}\" bol odstránený");
        } catch (\Exception $e) {
            $this->addFlash('danger', "Dokument sa nepodarilo odtrániť:  {$e->getMessage()}");
        }

        return $this->forward('App\Controller\DocumentController::indexAction');
    }

    /**
     * @Route("/delete-attachment/{attachmentId}", name="document_delete_attachment")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $attachmentId *
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function deleteAttachmentAction(int $attachmentId, DocumentService $documentService) {
        $em = $this->getDoctrine()->getManager();

        $attachment = $em->find(Attachment::class, $attachmentId);
        $document = $attachment->getDocument();
        $document->removeAttachment($attachment);
        $documentService->addDocumentHistoryRecord($attachment->getDocument(), "Odstránená príloha dokumentu [{$attachment->getName()}].");

        $em->flush();

        return $this->redirectToRoute('document_edit', ['documentId' => $document->getId()]);
    }

    /**
     * @Route("/download-attachment/{attachmentId}", name="document_download_attachment")
     * @param int $attachmentId
     * @param DocumentAttachmentService $documentAttachmentService
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Exception *
     */
    public function downloadAttachmentAction(int $attachmentId, DocumentAttachmentService $documentAttachmentService, DocumentService $documentService) {
        $em = $this->getDoctrine()->getManager();
        $attachment = $em->find(Attachment::class, $attachmentId);
        // TODO: Doplnit kontrolu opravneni
        $documentService->addDocumentHistoryRecord($attachment->getDocument(), "Zobrazená príloha dokumentu [{$attachment->getName()}].");

        return $this->file($documentAttachmentService->getAttachmentPath($attachment), $attachment->getName());
    }

    /**
     * @Route ("/add-step/{documentId}", name = "document_add_step")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $documentId
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function addProcessingStepAction(int $documentId, DocumentService $documentService) {
        $em = $this->getDoctrine()->getManager();
        $document = $em->find(Document::class, $documentId);
        $lastStepPosition = $em->getRepository(Document::class)->getLastProcessingStepPosition($documentId);
        $step = new ProcessingStep();
        $step->setDocument($document);
        $step->setPosition($lastStepPosition + 1);
        $em->persist($step);
        $em->flush();
        $documentService->addDocumentHistoryRecord($document, "Pridaný nový krok pre spracovanie dokumentu.");
        return $this->redirectToRoute('document_edit', ['documentId' => $documentId]);
    }

    /**
     * @Route ("/delete-step/{stepId}", name = "document_delete_step")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $stepId
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function deleteProcessingStepAction(int $stepId, DocumentService $documentService) {
        $em = $this->getDoctrine()->getManager();
        $step = $em->find(ProcessingStep::class, $stepId);
        $orgUnit = ($step->getOrgUnit())?$step->getOrgUnit()->getName():'Nepriradený';
        $em->remove($step);
        $em->flush();
        $documentService->addDocumentHistoryRecord($step->getDocument(), "Odstránený krok pre spracovanie dokumentu [{$orgUnit}].");
        return $this->redirectToRoute('document_edit', ['documentId' => $step->getDocument()->getId()]);
    }

    /**
     * @Route ("/confirm/{documentId}", name = "document_confirm")
     * @IsGranted("ROLE_USER")
     * @param Request $request
     * @param EntityManagerInterface $em
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function confirmAction(Request $request, EntityManagerInterface $em, DocumentService $documentService) {
        $documentId = $request->get('documentId');
        $document = $em->find(Document::class, $documentId);
        $step = $document->getActiveProcessingStep();

        $confirmationCommentModel = new ConfirmationComment();
        $form = $this->createForm(ConfirmDocumentType::class, $confirmationCommentModel);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $result = ($form->get('accept')->isClicked());
            $textResult = ($result) ? 'Odsúhlasenie' : 'Zamietnutie';
            $this->addFlash('success', "{$textResult} dokumentu bolo zaznamenané.");

            if ($result) {
                // odsuhlasny dokument
                $step->setStatus(ProcessingStep::STATUS_ACCEPTED);
                $nextStep = $document->getNextProcessingStep();
                $documentService->addDocumentHistoryRecord($step->getDocument(), "Dokument bol odsúhlasený oddelením {$step->getOrgUnit()->getName()}.");
                if ($nextStep) {
                    $nextStep->setActive(true);
                    $document->setState($em->getRepository(State::class)->find(Document::STATE_OPEN_ID));
                    $documentService->addDocumentHistoryRecord($step->getDocument(), "Dokument bol posunutý na oddelenie {$nextStep->getOrgUnit()->getName()}.");
                } else {
                    // uz nie je definovany dalsi krok, dokument je schvaleny
                    $step->setActive(false);
                    $document->setState($em->getRepository(State::class)->find(Document::STATE_READY_ID));
                    $documentService->addDocumentHistoryRecord($step->getDocument(), "Dokument bol schválený a posunutý na oddelenie kontroly.");
                }
            } else {
                // zamietnuty dokument
                $step->setStatus(ProcessingStep::STATUS_REJECTED);
                $step->setComment($form->get('comment')->getData());
                // zrusi sa aktivny krok procesu - dokument sa vracia na konrolu
                $step->setActive(false);
                $document->setState($em->getRepository(State::class)->find(Document::STATE_REJECTED_ID));
                $documentService->addDocumentHistoryRecord($step->getDocument(), "Dokument bol zamietnutý.");
            }

            $em->flush();

            return $this->redirectToRoute('document_pending');
        } else {
            $documentService->addDocumentHistoryRecord($step->getDocument(), "Dokument bol zobrazený na odsúhlasnie.");
            $document->setState($em->getRepository(State::class)->find(Document::STATE_REVIEWED_ID));
            $em->flush();
        }

        return $this->render('document/confirm.html.twig', array(
            'document'       => $document,
            'form'           => $form->createView()
        ));
    }

    /**
     * @Route ("/activate-step/{stepId}", name = "document_activate_step")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $stepId
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function activateProcessingStepAction(int $stepId, DocumentService $documentService) {

        try {
            $documentService->activateProcessingStep($stepId);
        } catch (\Exception $e) {
            $this->addFlash('danger', $e->getMessage());
        }

        $step = $this->getDoctrine()->getManager()->find(ProcessingStep::class, $stepId);
        return $this->redirectToRoute('document_edit', ['documentId' => $step->getDocument()->getId()]);
    }

    /**
     * @Route ("/start-process/{documentId}", name = "document_start_process")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $documentId
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function startProcessAction(int $documentId, DocumentService $documentService) {
        try {
            $documentService->startProcessing($documentId);
        } catch (\Exception $e) {
            $this->addFlash('danger', $e->getMessage());
        }

        return $this->redirectToRoute('document_edit', ['documentId' => $documentId]);
    }

    /**
     * @Route ("/restart-process/{documentId}", name = "document_restart_process")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $documentId
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function restartProcessAction(int $documentId, DocumentService $documentService) {
        try {
            $documentService->restartProcessing($documentId);
        } catch (\Exception $e) {
            $this->addFlash('danger', $e->getMessage());
        }

        return $this->redirectToRoute('document_edit', ['documentId' => $documentId]);
    }

    /**
     * @Route ("/pause-process/{documentId}", name = "document_pause_process")
     * @IsGranted("ROLE_CONTROLLING")
     * @param int $documentId
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function pauseProcessAction(int $documentId, DocumentService $documentService) {
        try {
            $documentService->pauseProcessing($documentId);
        } catch (\Exception $e) {
            $this->addFlash('danger', $e->getMessage());
        }

        return $this->redirectToRoute('document_edit', ['documentId' => $documentId]);
    }

    /**
     * @Route ("/update-step", name = "document_update_step")
     * @IsGranted("ROLE_CONTROLLING")
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function updateProcessingStepAction(Request $request, EntityManagerInterface $em) {
        $stepId = $request->get('stepId');
        $orgUnitId = $request->get('orgUnitId');
        $position = $request->get('position');
        $timeLimit = $request->get('timeLimit');
        try {
            $step = $em->find(ProcessingStep::class, $stepId);
            $step->setOrgUnit($em->find(OrgUnit::class, $orgUnitId));
            $step->setPosition($position);
            $step->setTimeLimit($timeLimit);

            $em->flush();
        } catch (\Throwable $e) {
            return $this->json(['success' => false, 'message' => "Chyba pri úprave kroku {$stepId}: {$e->getMessage()}"]);
        }

        return $this->json(['success' => true, 'message' => "Krok {$stepId} bol upraveny"]);
    }

    /**
     * Zoznam dokumentov, ktore cakaju na odsuhlasenie
     * @Route ("/pending", name = "document_pending")
     * @IsGranted("ROLE_USER")
     * @param UserInterface $user
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function pendingAction(UserInterface $user, EntityManagerInterface $em) {
        $userEntity = $em->getRepository(User::class)->findBy(['username' => $user->getUsername()])[0];

        $orgUnit = $userEntity->getOrgUnit();

        if ($orgUnit == null) {
            $documents = [];
            $this->addFlash('danger', "Prihlásený používateľ nie je zaradený pod žiadne oddelenie preto nemá pridelené žiadne dokumenty.");
        } else {
            $documents = $userEntity->getOrgUnit()->getDocuments();
        }

        return $this->render('document/pending.html.twig', array(
            'documents'       => $documents
        ));
    }

    /**
     * @Route ("/edit/{documentId}", defaults = {"documentId" = 0}, name = "document_edit")
     * @IsGranted("ROLE_CONTROLLING")
     * @param Request $request
     * @param DocumentAttachmentService $documentAttachmentService
     * @param LoggerInterface $logger
     * @param DocumentService $documentService
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function editDocumentAction(Request $request, DocumentAttachmentService $documentAttachmentService, LoggerInterface $logger, DocumentService $documentService) {
        $documentId = $request->get('documentId');
        $em = $this->getDoctrine()->getManager();
        if ($documentId == 0) {
            $document = new Document();
            // novy dokument dostane automaticky stav 1 a bude patrit na oddelenie kontroly
            $stateNew = $em->find(State::class, 1);
            $document->setState($stateNew);
        } else {
            $document = $em->find(Document::class, $documentId);
        }

        $form = $this->createForm(EditDocumentType::class, $document);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            try {
                $document = $form->getData();
                $isNew = $document->getId() == null;
                // TODO: Trochu skaredy sposob ako ziskat ID noveho dokumentu (zvazit pouzit napr UUID do nazvu suboru)
                if ($document->getId() == null) {
                    $em->persist($document);
                    $em->flush();
                }

                // nove subory
                $uploadedFiles = $form->get('uploadAttachment');
                foreach ($uploadedFiles->getData() as $file) {
                    $file = $documentAttachmentService->upload($document, $file);
                    $document->addAttachment($file);
                }

                // editovane subory
                $files = $form->get('attachments');
                foreach ($files as $file) {
                    $uploadedFile = $file->getData()->getUploadedFile();
                    if (!$uploadedFile) {
                        continue;
                    }
                    $documentAttachmentService->upload($document, $file->getData()->getUploadedFile(), $file->getData());
                }

                if ($isNew) {
                    $message = "Dokument bol vytvorený.";
                } else {
                    $message = "Dokument bol upravený.";
                }

                $documentService->addDocumentHistoryRecord($document, $message);

                $em->persist($document);
                $em->flush();

                $logger->info("Ulozeny dokument id: {$document->getId()}");
            } catch (\Exception $e) {
                $this->addFlash('danger', "Dokument sa nepodarilo uložiť: {$e->getMessage()}");
            }
            return $this->redirectToRoute('document_edit', ['documentId' => $document->getId()]);
        }
        return $this->render('document/edit.html.twig', array(
            'document'       => $document,
            'form' => $form->createView(),
        ));
    }
}
