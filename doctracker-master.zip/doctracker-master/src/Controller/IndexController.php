<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class IndexController extends AbstractController
{
    /**
     * @Route("/", name="index")
     * @param AuthorizationCheckerInterface $authChecker
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function index(AuthorizationCheckerInterface $authChecker)
    {
        if ($authChecker->isGranted('ROLE_ADMIN')) {
            return $this->redirectToRoute('document_index');
        } else if ($authChecker->isGranted('ROLE_CONTROLLING')) {
            return $this->redirectToRoute('document_index');
        } else if ($authChecker->isGranted('ROLE_USER')) {
            return $this->redirectToRoute('document_pending');
        }

        return $this->render('index/index.html.twig');
    }
}
