<?php

namespace App\Controller;

use App\Entity\User\OrgUnit;
use App\Form\OrgUnit\EditOrgUnitType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;

/**
 * Class OrgUnitController
 * @package App\Controller
 * @Route("/orgunits")
 * @IsGranted("ROLE_ADMIN")
 */
class OrgUnitController extends AbstractController
{
    /**
     * @Route("/", name="orgUnit_index")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function indexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $orgUnits = $em->getRepository(OrgUnit::class)->findAll();
        return $this->render('org_unit/index.html.twig', array(
            'orgUnists' => $orgUnits
        ));
    }

    /**
     * @Route("/delete/{orgUnitId}", name="orgUnit_delete")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function deleteOrgUnitAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $orgUnitId = $request->get('orgUnitId');
        $orgUnit = $em->find(OrgUnit::class, $orgUnitId);

        try {
            $em->remove($orgUnit);
            $em->flush();
            $this->addFlash('success', "Oddelenie bolo odstránené");
        } catch (\Exception $e) {
            $this->addFlash('danger', "Oddelenie sa nepodarilo odstrániť: {$e->getMessage()}");
        }
        return $this->forward('App\Controller\OrgUnitController::indexAction');
    }

    /**
     * @Route("/edit/{orgUnitId}", defaults = { "orgUnitId" = 0}, name = "orgUnit_edit")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function editOrgUnitAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $orgUnitId = $request->get('orgUnitId');

        if ($orgUnitId == 0) {
            $orgUnitModel = new OrgUnit();
        } else {
            $orgUnitModel = $em->find(OrgUnit::class, $orgUnitId);
        }

        $form = $this->createForm(EditOrgUnitType::class, $orgUnitModel);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            try {
                if ($orgUnitId == 0) {
                    $existingUserName = $em->getRepository(OrgUnit::class)->findBy(['name' => $orgUnitModel->getName()]);
                    if ($existingUserName) {
                        throw new \Exception("Oddelenie {$orgUnitModel->getName()} už existuje.");
                    }
                }
                $em->persist($orgUnitModel);
                $em->flush();
                if ($orgUnitId == 0) {
                    $this->addFlash('success', "Oddelenie {$orgUnitModel->getName()} bolo vytvorene");
                }else{
                    $this->addFlash('success' ,"Oddelenie {$orgUnitModel->getName()} bolo upravené");
                }
            } catch (\Exception $e) {
                $this->addFlash('danger', "Oddelenie sa nepodarilo vytvoriť: {$e->getMessage()}");
            }
            return $this->forward('App\Controller\OrgUnitController::indexAction');
        }
        return $this->render('org_unit/edit.html.twig', array(
           'form' => $form->createView()
        ));
    }
}
