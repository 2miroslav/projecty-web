<?php

namespace App\Controller;

use App\Entity\Document\Document;
use App\Entity\User\OrgUnit;
use App\Service\DocumentService;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

/**
 * @IsGranted("ROLE_ADMIN")
 * @Route("/statistics")
 */
class StatisticsController extends AbstractController
{
    /**
     * @Route("/", name="statistics_index")
     * @param DocumentService $documentService
     * @param EntityManagerInterface $em
     * @param LoggerInterface $logger
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function index(DocumentService $documentService, EntityManagerInterface $em, LoggerInterface $logger) {
        $documentStats = [];
        $ouStats = [];

        $documents = $em->getRepository(Document::class)->findAll();
        $orgUnits = $em->getRepository(OrgUnit::class)->findAll();

        foreach ($orgUnits as $ou) {
            $ouStats[$ou->getName()] = [
                'Poč. dokumentov' => 0,
                'Minimálne zdržanie' => -1,
                'Maximálne zdržanie' => -1,
                'Priemerné zdržanie' => -1,
            ];
        }

        foreach ($documents as $document) {
            $ds = $documentService->getDocumentStatistics($document->getId());

            $documentStats []= [
                'document' => $document,
                'ouTime' => $ds
            ];

            foreach ($ds as $ouName => $time) {
                if ($ouName == 'Celkový čas spracovania') {
                    continue;
                }

                if ($ouStats[$ouName]['Minimálne zdržanie'] < 0) {
                    $ouStats[$ouName]['Minimálne zdržanie'] = $time;
                }

                if ($ouStats[$ouName]['Maximálne zdržanie'] < 0) {
                    $ouStats[$ouName]['Maximálne zdržanie'] = $time;
                }

                if ($ouStats[$ouName]['Priemerné zdržanie'] < 0) {
                    $ouStats[$ouName]['Priemerné zdržanie'] = $time;
                }

                $ouStats[$ouName]['Poč. dokumentov']++;

                // pokial dokument na oddeleni nebol, nerata sa do statistiky
                if ($time > 0) {
                    if ($ouStats[$ouName]['Minimálne zdržanie'] > $time) {
                        $ouStats[$ouName]['Minimálne zdržanie'] = $time;
                    }

                    if ($ouStats[$ouName]['Maximálne zdržanie'] < $time) {
                        $ouStats[$ouName]['Maximálne zdržanie'] = $time;
                    }

                    $ouStats[$ouName]['Priemerné zdržanie'] = round(($ouStats[$ouName]['Priemerné zdržanie'] + $time) / 2);
                }
            }
        }

        return $this->render('statistics/index.html.twig', ['documentStats' => $documentStats, 'ouStats' => $ouStats]);
    }
}
