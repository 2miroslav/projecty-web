<?php

namespace App\Controller;

use App\Entity\User\User;
use App\Form\Model\ChangePassword;
use App\Form\User\ChangePasswordType;
use App\Form\User\EditUserType;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

/**
 * Class UserController
 * @package App\Controller
 */
class UserController extends AbstractController
{
    /**
     * @Route("/user", name="user_index")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     * @IsGranted("ROLE_ADMIN")
     */
    public function indexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $users = $em->getRepository(User::class)->findAll();

        return $this->render('user/index.html.twig', array(
            'users'   => $users
        ));
    }

    /**
     * @Route("/delete/{userId}", name="user_delete")
     * @param Request $request
     * @param LoggerInterface $logger
     * @return \Symfony\Component\HttpFoundation\Response
     * @IsGranted("ROLE_ADMIN")
     */
    public function deleteUserAction(Request $request, LoggerInterface $logger) {
        $em = $this->getDoctrine()->getManager();
        $userId = $request->get('userId');
        $logger->info("Odstranit pouzivatela {$userId}");
        $user = $em->find(User::class, $userId);

        try {
            if ($this->getUser()->getUsername() == $user->getUsername()) {
                throw new \Exception("Nie je možné zmazať samého seba");
            }
            $em->remove($user);
            $em->flush();
            $this->addFlash('success', "Používateľ {$user->getUsername()} bol odstránený");
        } catch (\Exception $e) {
            $this->addFlash('danger', "Používateľa sa nepodarilo odtrániť:  {$e->getMessage()}");
        }

        return $this->forward('App\Controller\UserController::indexAction');
    }

    /**
     * @Route("/edit/{userId}", defaults={"userId" = 0}, name="user_edit")
     * @param Request $request
     * @param LoggerInterface $logger
     * @return \Symfony\Component\HttpFoundation\Response
     * @IsGranted("ROLE_ADMIN")
     */
    public function editUserAction(Request $request, LoggerInterface $logger) {
        $em = $this->getDoctrine()->getManager();
        //$logger = $this->container->get('monolog.logger');
        $userId = $request->get('userId');

        if ($userId == 0) {
            $logger->info("Vytvorit noveho pouzivatela");
            $userModel = new User();
        } else {
            $logger->info("Upravit pouzivatela: {$userId}");
            $userModel = $em->find(User::class, $userId);
        }

        $form = $this->createForm(EditUserType::class, $userModel);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try {
                if ($userId == 0) {
                    $userModel->setPassword('');
                    $existingUsername = $em->getRepository(User::class)->findBy(['username' => $userModel->getUsername()]);

                    if ($existingUsername) {
                        throw new \Exception("Prihlasovacie meno {$userModel->getUsername()} je už obsadené.");
                    }
                }

                $em->persist($userModel);
                $em->flush();
                if ($userId == 0) {
                    $this->addFlash('success', "Používateľ {$userModel->getUsername()} bol vytvorený.");
                } else {
                    $this->addFlash('success', "Používateľ {$userModel->getUsername()} bol upravený.");
                }

            } catch (\Exception $e) {
                $this->addFlash('danger', "Používateľa sa nepodarilo uložiť: {$e->getMessage()}");
            }

            return $this->forward('App\Controller\UserController::indexAction');
        }

        return $this->render('user/edit.html.twig', array(
            'form'           => $form->createView()
        ));
    }

    /**
     * Zmena hesla pouzivatela s definovanym ID
     * @Route("/passwd/{userId}", defaults={"userId" = 0}, name="user_passwd")
     * @param Request $request
     * @param UserPasswordEncoderInterface $passwordEncoder
     * @param AuthorizationCheckerInterface $authChecker
     * @return \Symfony\Component\HttpFoundation\Response
     * @IsGranted("ROLE_USER")
     */
    public function passwdAction(Request $request, UserPasswordEncoderInterface $passwordEncoder, AuthorizationCheckerInterface $authChecker) {
        $userId = $request->get('userId');
        $em = $this->getDoctrine()->getManager();
        if ($userId == 0) {
            // ak nie je zadane id pouzivatela meni sa heslo prihlaseneho pouzivatela
            $user = $this->getUser();
        } else {
            // ak je zadane id pouzivatela, kontrolujem, ci je prihlaseny administrator
            if ($authChecker->isGranted('ROLE_ADMIN')) {
                $user =  $em->find(User::class, $userId);
            } else {
                $this->addFlash('danger', "Zmeniť heslo používateľa môže len administrátor.");
                return $this->redirectToRoute('index');
            }
        }

        $changePasswordModel = new ChangePassword();
        $form = $this->createForm(ChangePasswordType::class, $changePasswordModel);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            //$passwordEncoder = $this->get('security.password_encoder');
            $encodedPassword = $passwordEncoder->encodePassword($user, $changePasswordModel->getNewPassword());
            $user->setPassword($encodedPassword);
            $em->persist($user);
            $em->flush();
            $this->addFlash('success', "Heslo pre používateľa {$user->getUsername()} bolo zmenené");
        }

        return $this->render('user/passwd.html.twig', array(
            'user'           => $user,
            'form'           => $form->createView()
        ));
    }
}
