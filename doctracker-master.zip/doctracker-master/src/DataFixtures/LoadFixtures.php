<?php
namespace App\DataFixtures;

use App\Entity\Document\Document;
use App\Entity\Document\State;
use App\Entity\User\OrgUnit;
use App\Entity\User\Role;
use App\Entity\User\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Definicia dat pre inicializaciu databazy
 * Implementujem ContainerAwareInterface aby som mal jednoducho dostupne services z kontainera
 */
class LoadFixtures extends Fixture implements ContainerAwareInterface
{
    /** @var ContainerInterface */
    private $container;

    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        // ROLY
        $roleAdmin = new Role();
        $roleAdmin->setName(Role::ROLE_ADMIN);
        $roleAdmin->setDescription('Administrátor');
        $manager->persist($roleAdmin);

        $roleUser = new Role();
        $roleUser->setName(Role::ROLE_USER);
        $roleUser->setDescription('Používateľ');
        $manager->persist($roleUser);

        $roleControl = new Role();
        $roleControl->setName(Role::ROLE_CONTROLLING);
        $roleControl->setDescription('Kontrola');
        $manager->persist($roleControl);

        // OU
        $ouKontrola = new OrgUnit();
        $ouKontrola->setName("Oddelenie kontroly");
        $ouKontrola->setDocumentDefault(true);
        $manager->persist($ouKontrola);

        $ouObstaravanie = new OrgUnit();
        $ouObstaravanie->setName("Oddelenie obstarávania");
        $manager->persist($ouObstaravanie);

        $ouPravne = new OrgUnit();
        $ouPravne->setName("Právne oddelenie");
        $manager->persist($ouPravne);

        $ouRiaditel = new OrgUnit();
        $ouRiaditel->setName("Generálny riaditeľ");
        $manager->persist($ouRiaditel);

        // USERS
        $passwordEncoder = $this->container->get('security.password_encoder');

        $admin = new User();
        $admin->setUsername('admin');
        $admin->setFirstName('Admin');
        $admin->setSurname('Administrátor');
        $admin->setEmail('admin@doc-tracker.sk');
        $admin->addRole($roleAdmin);
        $encodedPassword = $passwordEncoder->encodePassword($admin, 'Pokus123');
        $admin->setPassword($encodedPassword);
        $manager->persist($admin);
        $this->addReference('user-admin', $admin);

        $user1 = new User();
        $user1->setUsername('kontrola');
        $user1->setFirstName('Michal');
        $user1->setSurname('Kontrolór');
        $user1->setEmail('user@doc-tracker.sk');
        $user1->addRole($roleControl);
        $user1->setOrgUnit($ouKontrola);
        $encodedPassword = $passwordEncoder->encodePassword($user1, 'Pokus123');
        $user1->setPassword($encodedPassword);
        $manager->persist($user1);

        $user2 = new User();
        $user2->setUsername('pravnik');
        $user2->setFirstName('Ján');
        $user2->setSurname('Právnik');
        $user2->setEmail('user@doc-tracker.sk');
        $user2->addRole($roleUser);
        $user2->setOrgUnit($ouPravne);
        $encodedPassword = $passwordEncoder->encodePassword($user2, 'Pokus123');
        $user2->setPassword($encodedPassword);
        $manager->persist($user2);

        $user3 = new User();
        $user3->setUsername('riaditel');
        $user3->setFirstName('Ondrej');
        $user3->setSurname('Riaditeľ');
        $user3->setEmail('user@doc-tracker.sk');
        $user3->addRole($roleUser);
        $user3->setOrgUnit($ouRiaditel);
        $encodedPassword = $passwordEncoder->encodePassword($user3, 'Pokus123');
        $user3->setPassword($encodedPassword);
        $manager->persist($user3);

        $user4 = new User();
        $user4->setUsername('obstaravanie');
        $user4->setFirstName('Janka');
        $user4->setSurname('Obstarávateľka');
        $user4->setEmail('user@doc-tracker.sk');
        $user4->addRole($roleUser);
        $user4->setOrgUnit($ouObstaravanie);
        $encodedPassword = $passwordEncoder->encodePassword($user4, 'Pokus123');
        $user4->setPassword($encodedPassword);
        $manager->persist($user4);

        // DOCUMENTS
        $state1 = new State();
        $state1->setId(Document::STATE_OPEN_ID);
        $state1->setName(Document::STATE_OPEN);
        $manager->persist($state1);

        $state2 = new State();
        $state2->setId(Document::STATE_REVIEWED_ID);
        $state2->setName(Document::STATE_REVIEWED);
        $manager->persist($state2);

        $state3 = new State();
        $state3->setId(Document::STATE_READY_ID);
        $state3->setName(Document::STATE_READY);
        $manager->persist($state3);

        $state4 = new State();
        $state4->setId(Document::STATE_CLOSED_ID);
        $state4->setName(Document::STATE_CLOSED);
        $manager->persist($state4);

        $state5 = new State();
        $state5->setId(Document::STATE_REJECTED_ID);
        $state5->setName(Document::STATE_REJECTED);
        $manager->persist($state5);

        $document = new Document();
        $document->setName('Prvý testovací dokument');
        $document->setDescription('Toto je prvý testovací dokument na testovanie zobrazenia v app');
        $document->setState($state1);
        $manager->persist($document);

        $document2 = new Document();
        $document2->setName('Druhý testovací dokument');
        $document2->setDescription('Toto je druhý testovací dokument na testovanie zobrazenia v app');
        $document2->setState($state1);
        $manager->persist($document2);

        $manager->flush();
    }

    /**
     * Vytvorit zoznam pouzivatelskych rol
     * @param ObjectManager $manager
     */
    private function loadUsers(ObjectManager $manager) {

    }

    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }
}
