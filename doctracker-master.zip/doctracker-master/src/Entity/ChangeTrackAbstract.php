<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Tuto triedu je mozne dedit v inych entitach. Tabulky tak ziskaju stlpce created a lastUpdate, v ktorych sa bude
 * automaticky evidovat cas vytvorenia a zmien.
 */

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\MappedSuperclass;

/**
 * @MappedSuperclass
 * @ORM\HasLifecycleCallbacks
 */
abstract class ChangeTrackAbstract {
    /**
     * Cas poslednej aktualizacie zaznamu
     * @var \DateTime
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $lastUpdate =null;


    /**
     * Cas vytvorenia zaznamu
     * @var \DateTime
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $created = null;


    /**
     * @return \DateTime
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @param mixed $created
     */
    public function setCreated($created) {
        $this->created = $created;
    }

    /**
     * @return mixed
     */
    public function getLastUpdate() {
        return $this->lastUpdate;
    }

    /**
     * @param mixed $lastUpdate
     */
    public function setLastUpdate($lastUpdate) {
        $this->lastUpdate = $lastUpdate;
    }

    /**
     * @ORM\PrePersist
     * @ORM\PreUpdate
     */
    public function updatedTimestamps() {
        // cas poslednej aktualizacie
        $this->setLastUpdate(new \DateTime());
        // cas vytvorenia
        if ($this->getCreated() == null) {
            $this->setCreated(new \DateTime());
        }
    }
}