<?php
/**
 * Trieda pre pracu s prilohami dokumentov
 */


namespace App\Entity\Document;

use Symfony\Component\HttpFoundation\File\UploadedFile;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="document_attachments")
 */
class Attachment {
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     * @var int
     */
    private $id;

    /**
     * Toto sa do DB neuklada. Sluzi len na docasne ulozenie suboru pri uploade
     * @var UploadedFile
     */
    private $uploadedFile;

    /**
     * @var Document
     * Pozor, nedefinovat cascade="remove" lebo inak sa pri zmazani suboru zmaze cely dokument
     * @ORM\ManyToOne(targetEntity="Document", inversedBy="attachments")
     * @ORM\JoinColumn(name="document_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $document;

    /**
     * @ORM\Column(type="string", length=200)
     * @var string
     */
    private $name;

    /**
     * Velkost suboru v byteoch
     * @ORM\Column(type="bigint")
     * @var int
     */
    private $size = 0;

    /**
     * @var string
     * @ORM\Column(type="string", length=100)
     */
    private $mimeType = '';

    /**
     * @var string
     * @ORM\Column(type="string", length=250)
     */
    private $filename;

    /**
     * V pripade potreby viacjazycnosti bude toto referencia na novu tabulku podobnu tabulke Content
     * @ORM\Column(type="text")
     * @var string
     */
    private $description = '';

    /**
     * Vlastniaci dokument sem vkladame preto, aby sa vytvorila aj opacna asociacia (teda contentu na dokument)
     * Asociacia sa musi vytvarat aj z tejto triedy, lebo pri ManyToOne je toto "owning side"
     * @param Document $owningDocument
     */
    public function __construct(Document $owningDocument) {
        $this->document = $owningDocument;
    }

    public function getIconClass() {
        $extension = pathinfo($this->filename, PATHINFO_EXTENSION);
        switch ($extension) {
            case 'doc':
            case 'docx':
                $class = 'fa-file-word text-primary';
                break;
            case 'xls':
            case 'xlsx':
                $class = 'fa-file-excel text-success';
                break;
            case 'pdf':
                $class = 'fa-file-pdf text-danger';
                break;
            case 'jpg':
            case 'jpeg':
            case 'bmp':
            case 'gif':
            case 'tiff':
                $class = 'fa-file-image';
                break;
            case 'zip':
            case 'rar':
                $class = 'fa-file-archive text-warning';
                break;
            default:
                $class = 'fa-file';
        }

        return $class;
    }

    /**
     * @return int
     */
    public function getId(): int {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void {
        $this->id = $id;
    }

    /**
     * @return UploadedFile
     */
    public function getUploadedFile(): ?UploadedFile {
        return $this->uploadedFile;
    }

    /**
     * @param UploadedFile $uploadedFile
     */
    public function setUploadedFile(UploadedFile $uploadedFile): void {
        $this->uploadedFile = $uploadedFile;
    }

    /**
     * @return Document
     */
    public function getDocument(): Document {
        return $this->document;
    }

    /**
     * @param Document $document
     */
    public function setDocument(Document $document): void {
        $this->document = $document;
    }

    /**
     * @return string
     */
    public function getName(): string {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void {
        $this->name = $name;
    }

    /**
     * @return int
     */
    public function getSize(): int {
        return $this->size;
    }

    /**
     * @param int $size
     */
    public function setSize(int $size): void {
        $this->size = $size;
    }

    /**
     * @return string
     */
    public function getMimeType(): string {
        return $this->mimeType;
    }

    /**
     * @param string $mimeType
     */
    public function setMimeType(string $mimeType): void {
        $this->mimeType = $mimeType;
    }

    /**
     * @return string
     */
    public function getFilename(): string {
        return $this->filename;
    }

    /**
     * @param string $filename
     */
    public function setFilename(string $filename): void {
        $this->filename = $filename;
    }

    /**
     * @return string
     */
    public function getDescription(): string {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void {
        $this->description = $description;
    }


}