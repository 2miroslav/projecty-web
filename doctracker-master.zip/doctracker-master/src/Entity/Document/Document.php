<?php

namespace App\Entity\Document;

use App\Entity\User\OrgUnit;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\DocumentRepository")
 */
class Document {
    const STATE_OPEN = 'Otvorený';
    const STATE_OPEN_ID = 1;
    const STATE_REVIEWED = 'Práve kontrolovaný';
    const STATE_REVIEWED_ID = 2;
    const STATE_REJECTED = 'Odmietnutý';
    const STATE_REJECTED_ID = 3;
    const STATE_READY = 'Pripravený';
    const STATE_READY_ID = 4;
    const STATE_CLOSED = 'Uzavrený';
    const STATE_CLOSED_ID = 5;

    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    /**
     * @var State
     * @ORM\ManyToOne(targetEntity="State", inversedBy="documents")
     * @ORM\JoinColumn(name="state_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $state = null;

    /**
     * @return OrgUnit
     */
    public function getOrgUnit(): ?OrgUnit {
        $orgUnit = null;

        foreach ($this->processingSteps as $step) {
            if ($step->isActive()) {
                $orgUnit = $step->getOrgUnit();
                break;
            }
        }

        return $orgUnit;
    }

    /**
     * Prilohy dokumentu
     * @var Collection
     * @ORM\OneToMany(targetEntity="App\Entity\Document\Attachment", mappedBy="document", cascade={"persist", "remove"}, orphanRemoval=true, fetch="EXTRA_LAZY")
     */
    private $attachments;

    /**
     * Kroky, ktore musi dokument absolvovat
     * @var Collection
     * @ORM\OneToMany(targetEntity="App\Entity\Document\ProcessingStep", mappedBy="document", cascade={"persist", "remove"}, orphanRemoval=true, fetch="EXTRA_LAZY")
     * @ORM\OrderBy({"position" = "ASC"})
     */
    private $processingSteps;

    /**
     * Historia dokumentu
     * @var Collection
     * @ORM\OneToMany(targetEntity="App\Entity\Document\HistoryRecord", mappedBy="document", cascade={"persist", "remove"}, orphanRemoval=true, fetch="EXTRA_LAZY")
     * @ORM\OrderBy({"created" = "ASC"})
     */
    private $history;

    public function __construct() {
        $this->attachments = new ArrayCollection();
        $this->processingSteps = new ArrayCollection();
        $this->history = new ArrayCollection();
    }

    /**
     * Nazov css triedy, ktora zodpoveda stavu dokumentu
     * @return string
     */
    public function getStateColorClass() {
        switch ($this->state->getId()) {
            case self::STATE_OPEN_ID:
                $class = 'info';
                break;
            case self::STATE_REVIEWED_ID:
                $class = 'warning';
                break;
            case self::STATE_REJECTED_ID:
                $class = 'danger';
                break;
            case self::STATE_READY_ID:
                $class = 'success';
                break;
            default:
                $class = 'secondary';
        }

        return $class;
    }

    /**
     * Ziskat historiu dokumentu
     * @return Collection<HistoryRecord>
     */
    public function getHistory(): Collection {
        return $this->history;
    }

    /**
     * Pridat zaznam do historie dokumentu
     * @param HistoryRecord $record
     */
    public function addHistoryRecord(HistoryRecord $record) {
        $this->history->add($record);
    }

    /**
     * @param ProcessingStep $step
     */
    public function addProcessingStep(ProcessingStep $step) {
        $this->processingSteps->add($step);
    }

    /**
     * @param ProcessingStep $step
     */
    public function removeProcessingStep(ProcessingStep $step) {
        foreach ($this->processingSteps as $key => $value) {
            if ($step->getId() == $value->getId()) {
                $this->processingSteps->remove($key);
            }
        }
    }

    /**
     * Ziskat datum a cas dokedy ma byt dokument schvaleny
     * @return \DateTime
     * @throws \Exception
     */
    public function getDeadline(): ?\DateTime {
        $activeStep = $this->getActiveProcessingStep();
        if ($activeStep && $activeStep->getActivationTime()) {
            $deadline = clone $activeStep->getActivationTime();
            $deadline->add(new \DateInterval("PT{$activeStep->getTimeLimit()}H"));
            return $deadline;
        } else {
            return null;
        }
    }

    /**
     * Ziskat pocet hodin ostavajucich do deadlinnu
     * @return int
     * @throws \Exception
     */
    public function getDeadlineCounter(): int {
        $activeStep = $this->getActiveProcessingStep();
        if ($activeStep && $activeStep->getActivationTime()) {
            $now = new \DateTime();
            $deadline = clone $activeStep->getActivationTime();
            $deadline->add(new \DateInterval("PT{$activeStep->getTimeLimit()}H"));
            return $now->diff($deadline)->format("%r%h");
        } else {
            return 0;
        }
    }

    /**
     * @return Collection
     */
    public function getProcessingSteps(): Collection {
        return $this->processingSteps;
    }

    /**
     * Ziskat aktivny krok spracovania dokumentu
     * @return ProcessingStep
     */
    public function getActiveProcessingStep(): ?ProcessingStep {
        foreach ($this->processingSteps as $step) {
            if ($step->isActive()) {
                return $step;
            }
        }
        return null;
    }

    /**
     * Ziskat dalsi krok, ktory nasleduje po aktivnom kroku spracovania
     * @return ProcessingStep
     */
    public function getNextProcessingStep(): ?ProcessingStep {
        $wasActiveStep = false;
        foreach ($this->processingSteps as $step) {
            if ($wasActiveStep) {
                return $step;
            }

            if ($step->isActive()) {
                $wasActiveStep = true;
            }
        }
        return null;
    }

    /**
     * @param Attachment $attachment
     */
    public function addAttachment(Attachment $attachment) {
        $this->attachments->add($attachment);
    }

    /**
     * @param Attachment $attachment
     */
    public function removeAttachment(Attachment $attachment) {
        foreach ($this->attachments as $key => $storedFile) {
            if ($storedFile->getFilename() == $attachment->getFilename()) {
                $this->attachments->remove($key);
            }
        }
    }

    /**
     * @return Collection
     */
    public function getAttachments(): Collection {
        return $this->attachments;
    }

    /**
     * @param Attachment $attachment
     */
    public function setAttachment(Attachment $attachment) {
        $fileExists = false;
        foreach ($this->attachments as $key => $storedFile) {
            if ($storedFile->getId() == $attachment->getId()) {
                $this->attachments->set($key, $attachment);
                $fileExists = true;
            }
        }

        if ($fileExists) {
            $this->attachments->add($attachment);
        }
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(int $id) {
        $this->id = $id;
    }

    public function getName(): ?string {
        return $this->name;
    }

    public function setName(string $name): self {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string {
        return $this->description;
    }

    public function setDescription(?string $description): self {
        $this->description = $description;

        return $this;
    }

    public function getState(): ?State {
        return $this->state;
    }

    public function setState(State $state): self {
        $this->state = $state;

        return $this;
    }

    public function __toString() {
        return "{$this->id}:{$this->name}";
    }
}
