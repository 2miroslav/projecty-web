<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 2. 10. 2018
 * Time: 14:16
 */

namespace App\Entity\Document;

use App\Entity\User\OrgUnit;
use App\Entity\User\User;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="document_history")
 */
class HistoryRecord {
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     * @var int
     */
    private $id;

    /**
     * @var Document
     * @ORM\ManyToOne(targetEntity="Document", inversedBy="history")
     * @ORM\JoinColumn(name="document_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $document;

    /**
     * Cas vytvorenia zaznamu
     * @var \DateTime
     * @ORM\Column(type="datetime")
     */
    private $created;

    /**
     * @var string
     * @ORM\Column(type="text", nullable=true)
     */
    private $message;

    /**
     * Pouzivatel, ktory je zodpovedny za zaznam
     * @var User
     * @ORM\ManyToOne(targetEntity="App\Entity\User\User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $user = null;

    /**
     * Organizacna jednotka, pod ktorou sa prave dokument nachadza
     * @var OrgUnit
     * @ORM\ManyToOne(targetEntity="App\Entity\User\OrgUnit")
     * @ORM\JoinColumn(name="ou_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $orgUnit = null;

    public function __construct(string $message = null, ?User $user = null) {
        $this->message = $message;
        $this->user = $user;
        $this->created = new \DateTime();
    }

    /**
     * @return OrgUnit
     */
    public function getOrgUnit(): ?OrgUnit {
        return $this->orgUnit;
    }

    /**
     * @param OrgUnit $orgUnit
     */
    public function setOrgUnit(?OrgUnit $orgUnit): void {
        $this->orgUnit = $orgUnit;
    }

    /**
     * @return User
     */
    public function getUser(): ?User {
        return $this->user;
    }

    /**
     * @param User $user
     */
    public function setUser(?User $user): void {
        $this->user = $user;
    }

    /**
     * @return string
     */
    public function getMessage(): string {
        return $this->message;
    }

    /**
     * @param string $message
     */
    public function setMessage(string $message): void {
        $this->message = $message;
    }

    /**
     * @return int
     */
    public function getId(): int {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void {
        $this->id = $id;
    }

    /**
     * @return Document
     */
    public function getDocument(): Document {
        return $this->document;
    }

    /**
     * @param Document $document
     */
    public function setDocument(Document $document): void {
        $this->document = $document;
    }

    /**
     * @return \DateTime
     */
    public function getCreated(): \DateTime {
        return $this->created;
    }
}