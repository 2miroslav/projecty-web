<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 2. 10. 2018
 * Time: 14:16
 */

namespace App\Entity\Document;

use App\Entity\User\OrgUnit;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="document_processing_step")
 */
class ProcessingStep {
    const STATUS_WAITING = 'waiting';
    const STATUS_ACCEPTED = 'accepted';
    const STATUS_REJECTED = 'rejected';

    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     * @var int
     */
    private $id;

    /**
     * @var Document
     * @ORM\ManyToOne(targetEntity="Document", inversedBy="processingSteps")
     * @ORM\JoinColumn(name="document_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $document;

    /**
     * @var OrgUnit
     * @ORM\ManyToOne(targetEntity="App\Entity\User\OrgUnit", inversedBy="processingSteps")
     * @ORM\JoinColumn(name="org_unit_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $orgUnit;

    /**
     * Casovy limit pre vyjadrenie k dokumentu v hodinach
     * @ORM\Column(type="integer")
     * @var int
     */
    private $timeLimit = 48;

    /**
     * Cas kedy bol krok aktivovany. Od tohto casu sa pocita limit na spracovanie.
     * @var \DateTime
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $activationTime = null;

    /**
     * Poradove cislo v procese spracovania
     * @var int
     * @ORM\Column(type="integer")
     */
    private $position = 0;

    /**
     * @var string
     * @ORM\Column(type="text", nullable=true)
     */
    private $comment = null;

    /**
     * @var string
     * @ORM\Column(type="string", length=50)
     */
    private $status;

    /**
     * Je aktualny krok aktivny?
     * @var bool
     * @ORM\Column(type="boolean")
     */
    private $active = false;

    public function __construct() {
        $this->status = self::STATUS_WAITING;
    }

    /**
     * @return string
     */
    public function getStatus(): string {
        return $this->status;
    }

    /**
     * @param string $status
     * @throws \Exception
     */
    public function setStatus(string $status): void {
        if (!in_array($status, [self::STATUS_WAITING, self::STATUS_ACCEPTED, self::STATUS_REJECTED])) {
            throw new \Exception("Neplatný status: {$status}");
        }
        $this->status = $status;
    }

    /**
     * @return string
     */
    public function getComment(): ?string {
        return $this->comment;
    }

    /**
     * @param string $comment
     */
    public function setComment(?string $comment): void {
        $this->comment = $comment;
    }

    /**
     * @return \DateTime
     */
    public function getActivationTime(): ?\DateTime {
        return $this->activationTime;
    }

    /**
     * @param \DateTime $activationTime
     */
    public function setActivationTime(?\DateTime $activationTime): void {
        $this->activationTime = $activationTime;
    }

    /**
     * @return int
     */
    public function getTimeLimit(): int {
        return $this->timeLimit;
    }

    /**
     * @param int $timeLimit
     */
    public function setTimeLimit(int $timeLimit): void {
        $this->timeLimit = $timeLimit;
    }

    /**
     * @return bool
     */
    public function isActive(): bool {
        return $this->active;
    }

    /**
     * @param bool $active
     */
    public function setActive(bool $active): void {
        // v pripade aktivacie treba osetrit daslie kroky a nastavit cas
        if ($active == true) {
            $steps = $this->document->getProcessingSteps();
            foreach ($steps as $step) {
                $step->setActive(false);
                $step->setComment(false);
            }
            $this->activationTime = new \DateTime();
        } else {
            $this->activationTime = null;
        }

        $this->active = $active;
    }

    /**
     * @return int
     */
    public function getPosition(): int {
        return $this->position;
    }

    /**
     * @param int $position
     */
    public function setPosition(int $position): void {
        $this->position = $position;
    }

    /**
     * @return OrgUnit
     */
    public function getOrgUnit(): ?OrgUnit {
        return $this->orgUnit;
    }

    /**
     * @param OrgUnit $orgUnit
     */
    public function setOrgUnit(OrgUnit $orgUnit): void {
        $this->orgUnit = $orgUnit;
    }

    /**
     * @return int
     */
    public function getId(): int {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void {
        $this->id = $id;
    }

    /**
     * @return Document
     */
    public function getDocument(): ?Document {
        return $this->document;
    }

    /**
     * @param Document $document
     */
    public function setDocument(Document $document): void {
        $this->document = $document;
    }

}