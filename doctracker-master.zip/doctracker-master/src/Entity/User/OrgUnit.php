<?php
/**
 * @author jsilaci
 * Oddelenia v orgranizacii. Do oddeleni bude mozne zaradovat ludi.
 */

namespace App\Entity\User;

use App\Entity\Document\Document;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="user_ous", indexes={@ORM\Index(name="defaultDocumentOu_idx", columns={"document_default"})})
 */
class OrgUnit
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     * @var int
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     * @var string
     */
    private $name;

    /**
     * @ORM\Column(type="string", length=400, nullable=true)
     * @var string
     */
    private $description;

    /**
     * @var \Doctrine\Common\Collections\Collection|User[]
     * @ORM\OneToMany(targetEntity="User", mappedBy="orgUnit")
     */
    private $users;

    /**
     * Kroky, ktore musia dokumenty absolvovat na tomto oddeleni
     * @var Collection
     * @ORM\OneToMany(targetEntity="App\Entity\Document\ProcessingStep", mappedBy="orgUnit", cascade={"persist", "remove"}, orphanRemoval=true, fetch="EXTRA_LAZY")
     */
    private $processingSteps;

    /**
     * Standardna OU pre dokumenty
     * @ORM\Column(type="boolean")
     * @var bool
     */
    private $documentDefault = false;

    /**
     * @return bool
     */
    public function isDocumentDefault(): bool {
        return $this->documentDefault;
    }

    /**
     * @param bool $documentDefault
     */
    public function setDocumentDefault(bool $documentDefault): void {
        $this->documentDefault = $documentDefault;
    }

    /**
     * @return Collection
     */
    public function getProcessingSteps():Collection {
        return $this->processingSteps;
    }

    /**
     * @return User[]|\Doctrine\Common\Collections\Collection
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * @param User[]|\Doctrine\Common\Collections\Collection $users
     */
    public function setUsers($users): void
    {
        $this->users = $users;
    }

    /**
     * Zoznam dokumentov, ktore su pridelene organizacnej jednotke
     * @return Collection
     */
    public function getDocuments(): Collection {
        $documents = new ArrayCollection();
        foreach ($this->processingSteps as $step) {
            if ($step->isActive()) {
                $documents->add($step->getDocument());
            }
        }

        return $documents;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function __construct()
    {
        $this->users = new ArrayCollection();
    }

    /**
     * @param User $user
     */
    public function addUser(User $user)
    {
        if ($this->users->contains($user)) {
            return;
        }
        $this->users->add($user);
        $user->setOrgUnit($this);
    }

    /**
     * @param User $user
     */
    public function removeUser(User $user)
    {
        if (!$this->users->contains($user)) {
            return;
        }
        $this->users->removeElement($user);
        $user->setOrgUnit(null);
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->name;
    }
}