<?php
/**
 * Automaticke akcie, ktore sa maju vykonat pri zmene priloh dokumentu
 */

namespace App\EventSubscriber;

use App\Entity\Document\Attachment;
use App\Service\DocumentAttachmentService;
use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Doctrine\ORM\Events;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;

class DocumentAttachmentSubscriber implements EventSubscriber {
    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var ParameterBagInterface
     */
    private $params;

    // TODO: Normalne by sa tu injektoval DocumentAttachmentService, ale z nejakeho dovodu to nie je mozne tak injektujem cely kontainer a potom ho z neho vytiahnem
    public function __construct(ParameterBagInterface $params, LoggerInterface $logger, ContainerInterface $container) {
        $this->container = $container;
        $this->logger = $logger;
        $this->params = $params;
    }

    /**
     * Zoznam eventov, na ktore bude subscriber reagovat.
     * @see https://www.doctrine-project.org/projects/doctrine-orm/en/latest/reference/events.html
     * @return array
     */
    public function getSubscribedEvents() {
        return array(
            Events::preRemove,
        );
    }

    /**
     * @param LifecycleEventArgs $args
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \Exception
     */
    public function preRemove(LifecycleEventArgs $args) {
        $object = $args->getEntity();
        // Ak je spracovavany objekt triedy attachement, tak vymaz subor
        if ($object instanceof Attachment) {
            $this->container->get(DocumentAttachmentService::class)->deleteAttachment($object);
        }
    }
}