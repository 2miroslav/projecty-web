<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 */

namespace App\Form\Document;

use App\Form\Model\ConfirmationComment;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;

class ConfirmDocumentType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('comment', TextareaType::class, array(
                'label' => "Komentár",
                'required' => false,
            ))
            ->add('accept', SubmitType::class, array(
                'label' => 'Odsúhlasiť',
                'attr' => array(
                    'class' => 'btn btn-success float-right'),
            ))
            ->add('reject', SubmitType::class, array(
                'label' => 'Zamietnuť',
                'attr' => array(
                    'class' => 'btn btn-danger float-right mr-1'),
            ))
            ->setMethod('post');
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => ConfirmationComment::class,
        ));
    }
}