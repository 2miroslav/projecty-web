<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 28.10.2017
 * Time: 22:48
 */

namespace App\Form\Document;


use App\Entity\Document\Attachment;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EditDocumentAttachmentType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {

        $builder
            ->add('id', HiddenType::class)
            ->add('name', TextType::class, [
                'label' => 'Názov',
            ])
            ->add('uploadedFile', FileType::class,
                [
                    'label' => 'Nahradiť súbor',
                    'mapped'   => true, // je to mapovane ale iba na docasne ulozenie kvoli uploadu nie na ulozenie do DB
                    'required' => false
                ]
            )
            ->add('description', TextareaType::class,
                [
                    'label' => 'Opis',
                    'required'   => false,
                    'empty_data' => ''
                ]
            );
    }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => Attachment::class,
        ));
    }
}