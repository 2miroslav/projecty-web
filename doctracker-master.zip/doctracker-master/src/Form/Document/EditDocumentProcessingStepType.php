<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 28.10.2017
 * Time: 22:48
 */

namespace App\Form\Document;


use App\Entity\Document\Attachment;
use App\Entity\Document\ProcessingStep;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\RadioType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EditDocumentProcessingStepType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {

        $builder
            ->add('id', HiddenType::class)
            ->add('orgUnit', EntityType::class,
                [
                    'label' => 'Oddelenie',
                    'class'        => 'App\Entity\User\OrgUnit',
                    'choice_name'   => 'id',
                    'choice_label' => 'name',
                    'multiple'     => false,
                    'expanded'     => false, // ak true budu to radiobuttony/checkboxy
                    'attr'         => [
                        'class' => 'select2'
                    ]
                ]
            )
            ->add('position', TextType::class,
                [
                    'label' => 'Poradové číslo',
                    'required'   => true,
                    'empty_data' => ''
                ]
            )
            ->add('timeLimit', TextType::class,
                [
                    'label' => 'Časový limit',
                    'required'   => true
                ]
            );
    }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => ProcessingStep::class,
        ));
    }
}