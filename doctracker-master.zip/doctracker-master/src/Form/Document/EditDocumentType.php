<?php

namespace App\Form\Document;

use App\Entity\Document\Document;
use App\Entity\User\OrgUnit;

use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Entity;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class EditDocumentType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder
            ->add('id', HiddenType::class)
            ->add('name', TextType::class,
                [
                    'label' => 'Názov'
                ]
            )
            ->add('description', TextareaType::class,
                [
                    'label' => 'Opis'
                ]
            )
            ->add('state', EntityType::class,
                [
                    'label' => 'Stav dokumentu',
                    'class'        => 'App\Entity\Document\State',
                    'choice_name' => 'id',
                    'choice_label' => 'name',
                    'multiple'     => false,
                    'expanded'     => false, // ak true budu to radiobuttony/checkboxy
                    'attr'         => [
                        'class' => 'select2'
                    ]
                ]
            )
            ->add('uploadAttachment', FileType::class,
                [
                    'label' => 'Nahrať prílohy',
                    'multiple' => true,
                    'mapped' => false,
                    'required' => false
                ]
            )
            ->add('attachments', CollectionType::class,
                [
                    'label' => false,
                    'entry_type' => EditDocumentAttachmentType::class,
                    'entry_options' => array('label' => false),
                ]
            )
            ->add('submit', SubmitType::class,
                [
                    'label' => 'Uložiť dokument',
                    'attr' => array(
                        'class' => 'btn btn-success'
                    ),
                ]
            )
            ->add('processingSteps', CollectionType::class,
                [
                    'label' => false,
                    'entry_type' => EditDocumentProcessingStepType::class,
                    'entry_options' => array('label' => false)
                ]
            )
            ->setMethod('post');

    }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => Document::class,
        ));
    }
}
