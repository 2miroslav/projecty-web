<?php

namespace App\Form\Model;

use Symfony\Component\Security\Core\Validator\Constraints as SecurityAssert;
use Symfony\Component\Validator\Constraints as Assert;

class ConfirmationComment {

    /**
     * @var string
     */
    protected $comment = null;

    /**
     * @return string
     */
    public function getComment() {
        return $this->comment;
    }

    /**
     * @param string $comment
     */
    public function setComment(?string $comment) {
        $this->comment = $comment;
    }


}
