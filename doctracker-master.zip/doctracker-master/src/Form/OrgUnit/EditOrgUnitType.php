<?php

namespace App\Form\OrgUnit;

use App\Entity\User\OrgUnit;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EditOrgUnitType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id', HiddenType::class)
            ->add('name', TextType::class, [
                'label' => "Názov oddelenia",
                'required' => true
            ])
            ->add('description', TextareaType::class, [
                'label' => 'Popis oddelenia',
                'required' => false
            ])
            ->add('documentDefault', CheckboxType::class, [
                'label' => 'Predvolené oddelenie pre dokumenty',
                'required' => false
            ])
            ->add('submit', SubmitType::class, array(
                'label' => 'Uložiť oddelenie',
                'attr' => array(
                    'class' => 'btn btn-info float-right'
                )
            ))
            ->setMethod('post');
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => OrgUnit::class
        ));
    }
}
