<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 */

namespace App\Form\User;

use App\Entity\User\User;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Validator\Constraints\NotBlank;

class EditUserType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $user = $builder->getData();
        $builder
            ->add('id', HiddenType::class)
            ->add('username', TextType::class, ['label' => "Prihlasovacie meno (login)"])
            ->add('firstName', TextType::class, [
                'label'      => "Meno",
                'required'   => false,
                'empty_data' => '' // v pripade, ze nic nezadam
            ])
            ->add('surname', TextType::class, [
                'label' => "Priezvisko",
                'required' => false,
                'empty_data' => ''
            ])
            ->add('email', EmailType::class, ['label' => "Mailová adresa"])
            ->add('roles', EntityType::class,
                [
                    'class'        => 'App\Entity\User\Role',
                    'choice_name' => 'name',
                    'multiple'     => true,
                    'expanded'     => false,
                    'attr'         => [
                        'class' => 'select2'
                    ],
                    'required' => true,
                ]
            )
            ->add('orgUnit', EntityType::class,
                [
                    'label' => 'Oddelenie',
                    'class'        => 'App\Entity\User\OrgUnit',
                    'choice_name' => 'name',
                    'multiple'     => false,
                    'expanded'     => false,
                    'attr'         => [
                        'class' => 'select2'
                    ],
                    'required' => true
                ]
            )
            ->add('submit', SubmitType::class, array(
                'label' => 'Uložiť používateľa',
                'attr' => array(
                    'class' => 'btn btn-info float-right'
                ),
            ))
            ->setMethod('post');
    }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            //'data_class' => EditUser::class,
            'data_class' => User::class,
        ));
    }
}