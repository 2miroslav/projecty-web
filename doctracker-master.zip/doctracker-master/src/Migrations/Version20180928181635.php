<?php declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20180928181635 extends AbstractMigration
{
    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE user_ous (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(100) NOT NULL, description VARCHAR(400) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_slovak_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user_roles (id VARCHAR(32) NOT NULL, description VARCHAR(100) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_slovak_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE users (id INT AUTO_INCREMENT NOT NULL, ou_id INT DEFAULT NULL, last_update DATETIME DEFAULT NULL, created DATETIME DEFAULT NULL, username VARCHAR(32) NOT NULL, first_name VARCHAR(64) NOT NULL, surname VARCHAR(64) NOT NULL, password VARCHAR(128) NOT NULL, email VARCHAR(128) NOT NULL, UNIQUE INDEX UNIQ_1483A5E9F85E0677 (username), INDEX IDX_1483A5E918A15B0D (ou_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_slovak_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user_role_rel (user_id INT NOT NULL, role_id VARCHAR(32) NOT NULL, INDEX IDX_A055B7CFA76ED395 (user_id), INDEX IDX_A055B7CFD60322AC (role_id), PRIMARY KEY(user_id, role_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_slovak_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE users ADD CONSTRAINT FK_1483A5E918A15B0D FOREIGN KEY (ou_id) REFERENCES user_ous (id) ON DELETE SET NULL');
        $this->addSql('ALTER TABLE user_role_rel ADD CONSTRAINT FK_A055B7CFA76ED395 FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE user_role_rel ADD CONSTRAINT FK_A055B7CFD60322AC FOREIGN KEY (role_id) REFERENCES user_roles (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE users DROP FOREIGN KEY FK_1483A5E918A15B0D');
        $this->addSql('ALTER TABLE user_role_rel DROP FOREIGN KEY FK_A055B7CFD60322AC');
        $this->addSql('ALTER TABLE user_role_rel DROP FOREIGN KEY FK_A055B7CFA76ED395');
        $this->addSql('DROP TABLE user_ous');
        $this->addSql('DROP TABLE user_roles');
        $this->addSql('DROP TABLE users');
        $this->addSql('DROP TABLE user_role_rel');
    }
}
