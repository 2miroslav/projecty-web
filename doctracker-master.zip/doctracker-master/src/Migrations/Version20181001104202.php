<?php declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20181001104202 extends AbstractMigration
{
    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE document_states (id INT NOT NULL, name VARCHAR(255) NOT NULL, description LONGTEXT DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_slovak_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE document ADD state_id INT DEFAULT NULL, DROP path, DROP link, DROP state');
        $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A765D83CC1 FOREIGN KEY (state_id) REFERENCES document_states (id) ON DELETE SET NULL');
        $this->addSql('CREATE INDEX IDX_D8698A765D83CC1 ON document (state_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A765D83CC1');
        $this->addSql('DROP TABLE document_states');
        $this->addSql('DROP INDEX IDX_D8698A765D83CC1 ON document');
        $this->addSql('ALTER TABLE document ADD path LONGTEXT NOT NULL COLLATE utf8mb4_slovak_ci, ADD link LONGTEXT NOT NULL COLLATE utf8mb4_slovak_ci, ADD state INT NOT NULL, DROP state_id');
    }
}
