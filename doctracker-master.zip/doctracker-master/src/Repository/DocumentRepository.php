<?php

namespace App\Repository;
use App\Entity\Document\Document;
use Doctrine\ORM\EntityRepository;

class DocumentRepository extends EntityRepository
{
    public function findAllOrderedByName() {
        return $this->getEntityManager()
            ->createQuery(
                'SELECT d FROM App\Entity\Document\Document d ORDER BY d.name ASC'
            )
            ->getResult();
    }

    /**
     * Posledny krok spracovania pre dokument
     * @param int $documentId
     * @return \App\Entity\Document\ProcessingStep
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function getLastProcessingStep(int $documentId):?\App\Entity\Document\ProcessingStep {
        return $this->getEntityManager()
            ->createQuery(
                'SELECT s FROM App\Entity\Document\ProcessingStep s JOIN s.document d WHERE d.id = ?1 ORDER BY s.position DESC'
            )
            ->setParameter(1, $documentId)
            ->setMaxResults(1)
            ->getOneOrNullResult();
    }

    /**
     * Posledne poradove cislo kroku spracovania pre dokument alebo 0 ak este nie su definovane kroky
     * @param int $documentId
     * @return int
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function getLastProcessingStepPosition(int $documentId):int {
        $result = $this->getEntityManager()
            ->createQuery(
                'SELECT s FROM App\Entity\Document\ProcessingStep s JOIN s.document d WHERE d.id = ?1 ORDER BY s.position DESC'
            )
            ->setParameter(1, $documentId)
            ->setMaxResults(1)
            ->getOneOrNullResult();

        return ($result)?$result->getPosition():0;
    }
}
