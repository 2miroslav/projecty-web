<?php
/**
 * Zatial nie je dovod pouzivat, nemame zlozite query na userov
 * User: jsilaci
 * Date: 07.10.2017
 * Time: 20:55
 */

namespace App\Repository;
use Doctrine\ORM\EntityRepository;
use App\Entity\User\User;

class UserRepository extends EntityRepository {
    public function findAllOrderedByUsername() {
        return $this->getEntityManager()
            ->createQuery(
                'SELECT u FROM App\Entity\User\User u ORDER BY u.username ASC'
            )
            ->getResult();
    }

    public function findByUsername(string $username):?User {
        $users = $this->findBy(['username' => $username]);

        return $users ? $users[0] : null;
    }
}