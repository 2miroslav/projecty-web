<?php
/**
 * Service pre pracu s prilohami
 */

namespace App\Service;


use App\Entity\Document\Attachment;
use App\Entity\Document\Document;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class DocumentAttachmentService {
    /**
     * @var string
     */
    private $filestorePath;

    /**
     * @var UtilitiesService
     */
    private $utils;

    /**
     * @var EntityManagerInterface
     */
    private $em;

    private $logger;

    public function __construct(string $filestorePath, UtilitiesService $utils, EntityManagerInterface $em, LoggerInterface $logger) {
        $this->filestorePath = $filestorePath;
        $this->utils = $utils;
        $this->em = $em;
        $this->logger = $logger;
    }

    /**
     * @return string
     */
    public function getFilestorePath() {
        return $this->filestorePath;
    }

    /**
     * Ziskat cestu k suboru prilohy
     * @param Attachment $attachment
     * @return string
     * @throws \Exception
     */
    public function getAttachmentPath(Attachment $attachment) {
        $fullPath = "{$this->filestorePath}/{$attachment->getFilename()}";

        if (!file_exists($fullPath)) {
            throw new \Exception("Súbor {$attachment->getFilename()} neexistuje.");
        }

        return "{$this->filestorePath}/{$attachment->getFilename()}";
    }

    /**
     * Uploadnut subor
     * @param Document $document
     * @param UploadedFile $uploadedFile
     * @param Attachment $existingFile Ak je definovane id, tak subor s tymto id bude nahradeny
     * @return Attachment
     * @throws \Exception
     */
    public function upload(Document $document,UploadedFile $uploadedFile, Attachment $existingFile = null): Attachment {
        if ($document == null) {
            throw new \Exception("Nie je definovaný dokument pre uploadovaný súbor.");
        }

        if ($existingFile != null) {
            $file = $existingFile;
            $fileName = $existingFile->getFilename();
            $name = $existingFile->getName();
        } else {
            $file = new Attachment($document);
            // Toto je vraj bezpecny sposob ziskania pripony lebo sa mu neda pripona podvrhnut
            // Castokrat tu ale neuhadne dobre, alebo proste vrati null, takze zatial nepouzivam
            // $extension = $uploadedFile->guessExtension();

            $extension = strtolower($uploadedFile->getClientOriginalExtension());

            if ($extension == 'jpeg') {
                $extension = 'jpg';
            }

            $index = 0;
            do {
                $index++;
                $fileName = $document->getId() . "-" . $this->utils->convertToFilenameFormat($document->getName()) . "-{$index}.{$extension}";
            } while (file_exists("{$this->getFilestorePath()}/{$fileName}"));

            $name = $uploadedFile->getClientOriginalName();
        }

        $mimeType = $uploadedFile->getMimeType();

        $file->setName($name);
        $file->setSize($uploadedFile->getSize());
        $file->setFilename($fileName);
        $file->setMimeType($mimeType);

        $uploadedFile->move($this->getFilestorePath(), $fileName);
        $this->logger->info("Subor {$fileName} bol presunuty do adresara {$this->getFilestorePath()}.");

        return $file;
    }

    /**
     * Vymazanie prilohy
     * @param Attachment $attachment
     * @throws \Exception
     */
    public function deleteAttachment(Attachment $attachment) {
        $filePath = "{$this->getFilestorePath()}/{$attachment->getFilename()}";

        if (file_exists($filePath)) {
            if (!unlink($filePath)) {
                throw new \Exception("Súbor \"{$filePath}\" sa nepodarilo vymazať zo servera.");
            }
        }

        $this->logger->info("Subor \"{$filePath}\" bol vymazany zo servera.");
    }
}