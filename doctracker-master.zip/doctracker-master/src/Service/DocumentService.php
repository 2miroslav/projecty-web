<?php
/**
 * Service pre pracu s prilohami
 */

namespace App\Service;


use App\Entity\Document\Attachment;
use App\Entity\Document\Document;
use App\Entity\Document\HistoryRecord;
use App\Entity\Document\ProcessingStep;
use App\Entity\User\OrgUnit;
use App\Entity\User\User;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Validator\Constraints\Date;

class DocumentService {

    /**
     * @var UtilitiesService
     */
    private $utils;

    /**
     * @var EntityManagerInterface
     */
    private $em;

    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var Security
     */
    private $security;

    public function __construct(UtilitiesService $utils, EntityManagerInterface $em, LoggerInterface $logger, ContainerInterface $container, Security $security) {
        $this->utils = $utils;
        $this->em = $em;
        $this->logger = $logger;
        $this->container = $container;
        $this->security = $security;
    }


    /**
     * Ziskat statistiku o spracovani dokumentu
     * @param int $documentId
     * @return array
     */
    public function getDocumentStatistics(int $documentId) {
        $history = $this->em->find(Document::class, $documentId)->getHistory();
        $ous = $this->em->getRepository(OrgUnit::class)->findAll();
        $stats = [];

        foreach ($ous as $ou) {
            $stats[$ou->getName()] = 0;
        }

        $totalTime = 0;

        foreach ($history as $r) {
            if (!isset($oldRecord) || ($r->getOrgUnit()->getId() != $oldRecord->getOrgUnit()->getId())) {
                $oldRecord = $r;
            }
            $time = $r->getCreated()->getTimestamp() - $oldRecord->getCreated()->getTimestamp();
            $stats[$r->getOrgUnit()->getName()] += $time;
            $totalTime += $time;
            $oldRecord = $r;
        }

        $stats['Celkový čas spracovania'] = $totalTime;

        return $stats;
    }

    /**
     * Spustit proces: nastavit prvy krok ako aktivny
     * @param $documentId
     * @throws \Exception
     */
    public function startProcessing($documentId) {
        try {
            $document = $this->em->find(Document::class, $documentId);
            $processingSteps = $this->em->find(Document::class, $documentId)->getProcessingSteps();
            $firstStep = $processingSteps->first();

            if (!$firstStep) {
                throw new \Exception("Dokument nemá definované žiadne kroky pre spracovanie");
            }

            $firstStep->setActive(true);
            $this->addDocumentHistoryRecord($document, "Proces spravovania bol spustený.");
            $this->addDocumentHistoryRecord($document, "Dokument bol posunutý na oddelenie {$firstStep->getOrgUnit()->getName()}.");
            $this->em->flush();
        } catch (\Throwable $e) {
            throw new \Exception("Chyba pri aktivácii procesu: {$e->getMessage()}");
        }
    }

    /**
     * Pozastavit proces: Aktivny krok bude deaktivovany a stiahnuty z oddelenia kem bol prideleny.
     * @param $documentId
     * @throws \Exception
     */
    public function pauseProcessing($documentId) {
        try {
            $document = $this->em->find(Document::class, $documentId);
            $activeStep = $document->getActiveProcessingStep();
            if (!$activeStep) {
                throw new \Exception("Dokument nemá aktívny žiadny krok spracovania");
            }
            $activeStep->setActive(false);
            $this->addDocumentHistoryRecord($document, "Dokument bol stiahnytý z oddelenia {$activeStep->getOrgUnit()->getName()}.");
            $this->addDocumentHistoryRecord($document, "Proces spravovania bol pozastavený.");
            $this->em->flush();
        } catch (\Throwable $e) {
            throw new \Exception("Chyba pri aktivácii procesu: {$e->getMessage()}");
        }
    }

    /**
     * Spustit proces: nastavit prvy krok ako aktivny
     * @param $documentId
     * @throws \Exception
     */
    public function restartProcessing($documentId) {
        $document = $this->em->find(Document::class, $documentId);
        $processingSteps = $document->getProcessingSteps();

        if (!$processingSteps) {
            throw new \Exception("Dokument, nemá definované žiadne kroky pre spracovanie.");
        }

        try {
            foreach ($processingSteps as $step) {
                $step->setActive(false);
                $step->setStatus(ProcessingStep::STATUS_WAITING);
            }

            $processingSteps->first()->setActive(true);
            $this->addDocumentHistoryRecord($document, "Proces spracovania bol reštartovaný.");
            $this->addDocumentHistoryRecord($document, "Dokument bol posunutý na oddelenie {$processingSteps->first()->getOrgUnit()->getName()}.");
            $this->em->flush();
        } catch (\Throwable $e) {
            throw new \Exception("Chyba pri aktivácii procesu: {$e->getMessage()}");
        }
    }

    /**
     * Nastavit konkretny krok ako oktivny. Ostatne ktoroky deaktivovat
     * @param int $stepId
     * @throws \Exception
     */
    public function activateProcessingStep(int $stepId) {
        $step = $this->em->find(ProcessingStep::class, $stepId);

        if (!$step) {
            throw new \Exception("Krok s {$stepId} ID neexistuje.");
        }

        $process = $step->getDocument()->getProcessingSteps();

        foreach ($process as $p) {
            if ($p->getId() == $stepId) {
                if ($step->getOrgUnit() !== null) {
                    $step->setStatus(ProcessingStep::STATUS_WAITING);
                    $step->setActive(true);
                    $this->addDocumentHistoryRecord($step->getDocument(), "Dokument bol posunutý na oddelenie {$step->getOrgUnit()->getName()}.");
                } else {
                    throw new \Exception("Krok spracovania nemá definované oddelenie. Nie je možné ho spustiť.");
                }
            } else {
                $step->setActive(false);
            }
        }

        $this->em->flush();
    }

    /**
     * Pridat zaznam do historie dokumentu
     * @param Document $document
     * @param string $message
     */
    public function addDocumentHistoryRecord(Document $document, string $message) {
        $username = $this->security->getUser()->getUsername();
        $user = $this->em->getRepository(User::class)->findByUsername($username);
        $record = new HistoryRecord($message, $user);
        $record->setDocument($document);
        $orgUnit = ($document->getOrgUnit())?$document->getOrgUnit():$this->em->getRepository(OrgUnit::class)->findOneBy(['documentDefault' => true]);
        $record->setOrgUnit($orgUnit);
        $this->em->persist($record);
        // TODO: Otazka, ci je toto mozne optimalizovat - ak vobec treba - treba preverit SQL query, ktore to generuje
        $this->em->flush();
    }

}