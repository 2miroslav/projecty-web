<?php
/**
 * Created by PhpStorm.
 * User: miroslav
 * Date: 15.10.2018
 * Time: 8:59
 */

namespace App\Service;

use Swift_Mailer;

class NotificationService
{
    /**
     * @var Swift_Mailer
     */
    private $mailSwifter;

    /**
     * @var \Twig_Environment
     */
    private $twig;

    /**
     * NotificationService constructor.
     * @param \Twig_Environment $twig
     * @param Swift_Mailer $mailer
     */
    public function __construct(\Twig_Environment $twig, \Swift_Mailer $mailer) {
        $this->mailSwifter = $mailer;
        $this->twig = $twig;
    }

    public function sendNotification($subject, $sendTo, $bodyEmail) {

        $messageEmail = (new \Swift_Message($subject))
            // Kto posiela email
            ->setFrom(['test.emails.projects@gmail.com' => 'Testovaci email'])
            //Komu sa posiela email moze byt pole
            ->setTo($sendTo)
            //Vytvori sa view a nasledne sa do neho vlozia data ako pri renderovani stranky
            ->setBody($this->twig->render('emailNotifications/newDocument.html.twig',
                array('id' => $bodyEmail['id'],
                        'name' => $bodyEmail['name'],
                        'description' => $bodyEmail['description']
                )),
                'text/html');
        //Odosle email
        return $this->mailSwifter->send($messageEmail);
    }
}