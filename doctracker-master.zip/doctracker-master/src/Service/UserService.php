<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 8. 10. 2018
 * Time: 15:27
 */

namespace App\Service;


use App\Entity\User\User;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Security\Core\Security;

class UserService {
    /**
     * @var UtilitiesService
     */
    private $utils;

    /**
     * @var EntityManagerInterface
     */
    private $em;

    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var Security
     */
    private $security;

    public function __construct(UtilitiesService $utils, EntityManagerInterface $em, LoggerInterface $logger, ContainerInterface $container, Security $security) {
        $this->utils = $utils;
        $this->em = $em;
        $this->logger = $logger;
        $this->container = $container;
        $this->security = $security;
    }

    public function getAllUsers() {
        return $this->em->getRepository(User::class)->findAllOrderedByUsername();
    }

    public function getUserDetails(string $username) {
        return  $this->em->getRepository(User::class)->findByUsername($username);
    }
}