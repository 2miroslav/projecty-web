<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 02.11.2017
 * Time: 8:44
 */

namespace App\Service;


use Monolog\Logger;
use Psr\Log\LoggerInterface;

class UtilitiesService {
    /**
     * @var Logger
     */
    private $logger;

    /**
     * Konvertovat retazec na format vhodny pre nazov suboru
     * @param string $text
     * @return string
     */
    public function convertToFilenameFormat(string $text):string {
        $text = strtolower($this->removeDiacritics($text));

        $text = preg_replace("%[^a-zA-Z0-9]%", "-", $text);
        $text = preg_replace("%-+%", "-", $text);
        $text = preg_replace("%-$%", "", $text);

        return $text;
    }

    /**
     * Odstranit diakritiku
     * @param string $text
     * @return string
     */
    public function removeDiacritics(string $text):string {
        $utf8 = array(
            "Á" => "A", // Á
            "Ä" => "A", // Ä
            "Č" => "C", // Č
            "Ć" => "C", // Ć
            "Ď" => "D", // D
            "É" => "E", // É
            "Ë" => "E", // Ë
            "Ě" => "E", // Ě
            "Í" => "I", // Í
            "Ľ" => "L", // L
            "Ĺ" => "L", // L
            "Ł" => "L", // Ł
            "Ň" => "N", // N
            "Ó" => "O", // Ó
            "Ô" => "O", // Ô
            "Ö" => "O", // Ö
            "Ő" => "O", // Ő
            "Ŕ" => "R", // R
            "Ř" => "R", // R
            "Š" => "S", // Š
            "Ś" => "S",
            "Ť" => "T", // T
            "Ú" => "U", // Ú
            "Ů" => "U", // U
            "Ü" => "U", // Ü
            "Ű" => "U", // Ű
            "Ý" => "Y", // Ý
            "Ž" => "Z", // Ž
            "ß" => "ss", // ß
            "á" => "a", // á
            "ä" => "a", // ä
            "ā" => "a", // ā
            "č" => "c", // c
            "ć" => "c", // c
            "ç" => "c", // ç
            "ď" => "d", // d
            "đ" => "d", // đ
            "é" => "e", // é
            "ë" => "e", // ë
            "ě" => "e", // ě
            "í" => "i", // í
            "î" => "i", // î
            "ľ" => "l", // ľ
            "ĺ" => "l", // ĺ
            "ł" => "l", // ł
            "ň" => "n", // ň
            "ń" => 'n', // ń
            "ó" => "o", // ó
            "ô" => "o", // ô
            "ö" => "o", // ö
            "ő" => "o", // ő
            "ř" => "r", // ř
            "ŕ" => "r", // ŕ
            "š" => "s", // š
            "ś" => "s",
            "ť" => "t", // ť
            "ú" => "u", // ú
            "ů" => "u", // ů
            "ü" => "u", // ü
            "ű" => "u", // ű
            "ū" => "u", // ū
            "ý" => "y", // ý
            "ž" => "z", // ž
            "ż" => "z", // ż
            "®" => "", //
            "`" => "", //
            "̎" => "", //
            "´" => ""
        );

        $plain = strtr($text, $utf8);

        return $plain;
    }

    public function __construct(LoggerInterface $logger) {
        $this->logger = $logger;
        return $this;
    }
}