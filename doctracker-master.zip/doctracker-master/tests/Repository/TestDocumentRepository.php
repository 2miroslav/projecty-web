<?php
/**
 * Testy pre Document repository
 * @author jsilaci
 */

namespace App\Tests;

use App\Entity\Document\Document;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class TestDocumentRepository extends KernelTestCase {
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    /**
     * {@inheritDoc}
     */
    protected function setUp()
    {
        $kernel = self::bootKernel();

        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();
    }

    /**
     * {@inheritDoc}
     */
    protected function tearDown()
    {
        parent::tearDown();

        $this->entityManager->close();
        $this->entityManager = null; // avoid memory leaks
    }

    public function testFindAllOrderedByName() {
        $documents = $this->entityManager
            ->getRepository(Document::class)->findAllOrderedByName();

        $this->assertEquals(2, count($documents));
        $this->assertInstanceOf(Document::class, $documents[0]);
        $this->assertInstanceOf(Document::class, $documents[1]);
        $this->assertEquals('Druhý testovací dokument', $documents[0]->getName());
        $this->assertEquals('Prvý testovací dokument', $documents[1]->getName());
    }

    /**
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function testGetLastProcessingStep() {
        $documents = $this->entityManager
            ->getRepository(Document::class)->findAll();

        $document = $documents[1];

        $lastStep = $this->entityManager
            ->getRepository(Document::class)->getLastProcessingStepPosition($document->getId());

        var_dump($lastStep);
    }
}
