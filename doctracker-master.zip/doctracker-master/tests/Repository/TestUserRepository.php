<?php
/**
 * Testy pre User repository
 * @author jsilaci
 */

namespace App\Tests;

use App\Entity\User\User;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class TestUserRepository extends KernelTestCase {
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    /**
     * {@inheritDoc}
     */
    protected function setUp()
    {
        $kernel = self::bootKernel();

        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();
    }

    /**
     * {@inheritDoc}
     */
    protected function tearDown()
    {
        parent::tearDown();

        $this->entityManager->close();
        $this->entityManager = null; // avoid memory leaks
    }

    public function testFindAllOrderedByUsername() {
        $users = $tree = $this->entityManager
            ->getRepository(User::class)->findAllOrderedByUsername();

        $this->assertEquals(2, count($users));
        $this->assertInstanceOf(User::class, $users[0]);
        $this->assertInstanceOf(User::class, $users[1]);
        $this->assertEquals('admin', $users[0]->getUsername());
        $this->assertEquals('user', $users[1]->getUsername());
    }
}
