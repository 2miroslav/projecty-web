<?php
/**
 * Created by PhpStorm.
 * User: jsilaci
 * Date: 30. 9. 2018
 * Time: 14:40
 */

namespace App\Tests\Service;

use App\Entity\Document\Document;
use App\Service\DocumentAttachmentService;
use PhpParser\Comment\Doc;
use Psr\Container\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class TestDocumentAttachmentService extends KernelTestCase {
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    /**
     * @var DocumentAttachmentService
     */
    private $documentAttachmentService;


    /**
     * {@inheritDoc}
     */
    protected function setUp()
    {
        $kernel = self::bootKernel();
        $this->documentAttachmentService = $kernel->getContainer()->get(DocumentAttachmentService::class);
        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();
    }

    /**
     * {@inheritDoc}
     */
    protected function tearDown()
    {
        parent::tearDown();

        $this->entityManager->close();
        $this->entityManager = null; // avoid memory leaks
    }

    public function testGetFilestorePath() {
        $path = $this->documentAttachmentService->getFilestorePath();
        $this->assertRegExp("%/var/attachment%", $path);
    }

    /**
     *
     * @throws \Exception
     */
    public function testUpload() {
        $documents = $this->entityManager->getRepository(Document::class)->findAll();

        $document = $documents[0];
        $documentId = $document->getId();

        file_put_contents("d:/test.txt", "Testovaci subor");
        // posledny parameter musi byt true - aktivny rezim testovania
        $uploadedFile = new UploadedFile("d:\\test.txt", "test.txt", null, null, true);

        $attachment = $this->documentAttachmentService->upload($document, $uploadedFile);

        $filename = $this->documentAttachmentService->getFilestorePath() . '/' . $attachment->getFilename();

        $this->assertTrue(file_exists($filename));

        $this->entityManager->persist($attachment);

        $this->entityManager->flush();

        $document2 = $this->entityManager->getRepository(Document::class)->find($documentId);

        $attachements = $document2->getAttachments();

        $this->assertTrue($attachements->count() > 0);
    }

    /**
     * @throws \Exception
     */
    public function testDelete() {
        $documents = $this->entityManager->getRepository(Document::class)->findAll();

        $document = $documents[0];

        $attachments = $document->getAttachments();

        if ($attachments->count() == 0) {
            throw new \Exception("Testovaci dokument nema ziadnu prilohu.");
        }

        $attachment = $attachments->first();

        $document->removeAttachment($attachment);

        $this->entityManager->persist($document);

        $this->entityManager->flush();

        $this->assertTrue(!file_exists($this->documentAttachmentService->getFilestorePath() . '/' . $attachment->getFilename()));
    }
}
